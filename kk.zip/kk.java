import javax.swing.*;

public class kk {
    public static void main(String[] args) {
     double a[]= new double [4], sum=0.0;
     int neg =0 , pos =0 , odd = 0,even=0; 
     for (int i=0; i<a.length; i++){
a[i]= Double.parseDouble(JOptionPane.showInputDialog("ادخل الرقم "));
sum+=a[i];
if (a[i]>=0)pos++;
else neg++;
if (a[i]%2==0) even++;
else odd++;
     }

     JOptionPane.showMessageDialog(null,"مجموع الاعداد "+sum+"\n"+"الاعداد الفرديه"+odd+"\n"+"الاعداد الزوجيه"+even+"\n "+"الاعداد السالبه " +neg +"\n "+"الاعداد الموجبخ "+pos+"\n"+"متوسط الاعداد المتوسطه"+sum/a.length);

    }
    
}
